import pool from '../db/db.js';

export const getUsers = async (req, res) => {
  try {
    const result = await pool.query('SELECT id, name, email FROM users');
    res.status(200).json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Foydalanuvchini malumotlarida xatolik bor' });
  }
};

export const getUserById = async (req, res) => {
  const { userId } = req.params;
  try {
    const result = await pool.query('SELECT id, name, email FROM users WHERE id = $1', [userId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Bunaqa foydalanuvchi yoqku. kimi lox qmochisiz' });
    }
    res.status(200).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Foydalanuvchini malumotlarida xatolik bor' });
  }
};

export const updateUser = async (req, res) => {
  const { userId } = req.params;
  const { name, email } = req.body;
  try {
    const result = await pool.query(
      'UPDATE users SET name = $1, email = $2 WHERE id = $3 RETURNING id, name, email',
      [name, email, userId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Bunaqa foydalanuvchi yoqku. kimi lox qmochisiz' });
    }
    res.status(200).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Malumotlarni yangilashda xatolik bor' });
  }
};

export const deleteUser = async (req, res) => {
  const { userId } = req.params;
  try {
    await pool.query('UPDATE tasks SET "userId" = NULL WHERE "userId" = $1', [userId]);
    const result = await pool.query('DELETE FROM users WHERE id = $1 RETURNING id, name, email', [userId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Bunaqa foydalanuvchi yoqku. kimi lox qmochisiz' });
    }
    res.status(200).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Malumotlani ochirishda xatolik bor' });
  }
};
