import express from 'express';
import bodyParser from 'body-parser';
import { Pool } from 'pg';
import dotenv from 'dotenv';

import authRoutes from './routes/authRoutes';
import userRoutes from './routes/userRoutes';
import boardRoutes from './routes/boardRoutes';
import taskRoutes from './routes/taskRoutes';

dotenv.config();

const app = express();
const PORT = 4000;

app.use(bodyParser.json());

app.use('/auth', authRoutes);
app.use('/users', userRoutes);
app.use('/boards', boardRoutes);
app.use('/boards/:boardId/tasks', taskRoutes);

app.post('/setUp', async (req, res) => {
  try {
    const pool = new Pool();
    await pool.query(`CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL CHECK(LENGTH(password)>5)
      );

      CREATE TABLE IF NOT EXISTS boards (
        id SERIAL PRIMARY KEY,
        title VARCHAR(255) NOT NULL
      );

      CREATE TABLE IF NOT EXISTS tasks (
        id SERIAL PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        "order" INTEGER,
        description TEXT,
        "userId" INTEGER REFERENCES users(id) ON DELETE SET NULL,
        "boardId" INTEGER REFERENCES boards(id) ON DELETE CASCADE
      ); `); // password VARCHAR(255) NOT NULL CHECK(LENGTH(password)>5) bu shartni shunchaki o'zim qo'shdim
    res.status(200).send('aka siz zorisiz!!! Tabellarni yaratib tashladiz oma gap yoq');
  } catch (err) {
    res.status(500).send('Errorjon!!! xoo ushetda xato qigansiz ushani togirlavoring');
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
