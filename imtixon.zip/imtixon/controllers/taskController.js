import pool from '../db/db.js';

export const getTasks = async (req, res) => {
  const { boardId } = req.params;
  try {
    const result = await pool.query('SELECT * FROM tasks WHERE "boardId" = $1', [boardId]);
    res.status(200).json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'malumot toliq emas' });
  }
};

export const getTaskById = async (req, res) => {
  const { boardId, taskId } = req.params;
  try {
    const result = await pool.query('SELECT * FROM tasks WHERE id = $1 AND "boardId" = $2', [taskId, boardId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'bizni lox deb oylaysizmi? bunday topshiriq yoqku' });
    }
    res.status(200).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'xato' });
  }
};

export const createTask = async (req, res) => {
  const { boardId } = req.params;
  const { title, order, description, userId, columnId } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO tasks (title, "order", description, "userId", "boardId", "columnId") VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
      [title, order, description, userId, boardId, columnId]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'topshiriqni yaratishda muammo' });
  }
};

export const updateTask = async (req, res) => {
  const { boardId, taskId } = req.params;
  const { title, order, description, userId, columnId } = req.body;
  try {
    const result = await pool.query(
      'UPDATE tasks SET title = $1, "order" = $2, description = $3, "userId" = $4, "columnId" = $5 WHERE id = $6 AND "boardId" = $7 RETURNING *',
      [title, order, description, userId, columnId, taskId, boardId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'bizni lox deb oylaysizmi? bunday topshiriq yoqku' });
    }
    res.status(200).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'topshiriqni yangilashda muamo bor' });
  }
};

export const deleteTask = async (req, res) => {
  const { boardId, taskId } = req.params;
  try {
    const result = await pool.query('DELETE FROM tasks WHERE id = $1 AND "boardId" = $2 RETURNING *', [taskId, boardId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'bunaqa topshiriq topilmadi' });
    }
    res.status(200).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'topshiriqni ochirishda muammo bor' });
  }
};
