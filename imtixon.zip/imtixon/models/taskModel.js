import pool from '../db/db.js';

const getAllTasks = async (boardId) => {
  const result = await pool.query('SELECT * FROM tasks WHERE "boardId" = $1', [boardId]);
  return result.rows;
};

const getTaskById = async (boardId, taskId) => {
  const result = await pool.query('SELECT * FROM tasks WHERE id = $1 AND "boardId" = $2', [taskId, boardId]);
  return result.rows[0];
};

const createTask = async (title, order, description, userId, boardId, columnId) => {
  const result = await pool.query(
    'INSERT INTO tasks (title, "order", description, "userId", "boardId", "columnId") VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
    [title, order, description, userId, boardId, columnId]
  );
  return result.rows[0];
};

const updateTask = async (taskId, boardId, title, order, description, userId, columnId) => {
  const result = await pool.query(
    'UPDATE tasks SET title = $1, "order" = $2, description = $3, "userId" = $4, "columnId" = $5 WHERE id = $6 AND "boardId" = $7 RETURNING *',
    [title, order, description, userId, columnId, taskId, boardId]
  );
  return result.rows[0];
};

const deleteTask = async (taskId, boardId) => {
  const result = await pool.query('DELETE FROM tasks WHERE id = $1 AND "boardId" = $2 RETURNING *', [taskId, boardId]);
  return result.rows[0];
};

export {
  getAllTasks,
  getTaskById,
  createTask,
  updateTask,
  deleteTask
};
