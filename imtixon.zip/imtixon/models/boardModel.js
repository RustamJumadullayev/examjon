import pool from '../db/db.js';

const getAllBoards = async () => {
  const result = await pool.query('SELECT * FROM boards');
  return result.rows;
};

const getBoardById = async (boardId) => {
  const result = await pool.query('SELECT * FROM boards WHERE id = $1', [boardId]);
  return result.rows[0];
};

const createBoard = async (title, columns) => {
  const result = await pool.query(
    'INSERT INTO boards (title, columns) VALUES ($1, $2) RETURNING *',
    [title, columns]
  );
  return result.rows[0];
};

const updateBoard = async (boardId, title, columns) => {
  const result = await pool.query(
    'UPDATE boards SET title = $1, columns = $2 WHERE id = $3 RETURNING *',
    [title, columns, boardId]
  );
  return result.rows[0];
};

const deleteBoard = async (boardId) => {
  await pool.query('DELETE FROM tasks WHERE "boardId" = $1', [boardId]); 
  const result = await pool.query('DELETE FROM boards WHERE id = $1 RETURNING *', [boardId]);
  return result.rows[0];
};

export {
  getAllBoards,
  getBoardById,
  createBoard,
  updateBoard,
  deleteBoard
};
