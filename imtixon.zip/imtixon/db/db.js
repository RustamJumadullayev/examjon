const { Pool } = require('pg');
const pool = new Pool({
  user: ' ', // nima yozish esimdan chiqibti uzur
  host: 'localhost',
  database: 'imtixon',
  password: 'rustam110103',
  port: 5432,
});

module.exports = pool;
