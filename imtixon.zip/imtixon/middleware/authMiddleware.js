import jwt from 'jsonwebtoken';

const authMiddleware = (req, res, next) => {
  const token = req.header('Authorization')?.replace('Bearer ', ''); // Added optional chaining to avoid errors if header is not present
  if (!token) {
    return res.status(401).json({ error: 'xatolik bor' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(400).json({ error: 'Notori olingan' });
  }
};

export default authMiddleware;
