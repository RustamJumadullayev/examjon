import pool from '../db/db.js';

export const getBoards = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM boards');
    res.status(200).json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Boardni toldirishda xatolik bor' });
  }
};

export const getBoardById = async (req, res) => {
  const { boardId } = req.params;
  try {
    const result = await pool.query('SELECT * FROM boards WHERE id = $1', [boardId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Bunday board topilmadi' });
    }
    res.status(200).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Boardni toldirishda xatolik bor' });
  }
};

export const createBoard = async (req, res) => {
  const { title, columns } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO boards (title, columns) VALUES ($1, $2) RETURNING *',
      [title, columns]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Boardni yaratishda xatolik bor' });
  }
};

export const updateBoard = async (req, res) => {
  const { boardId } = req.params;
  const { title, columns } = req.body;
  try {
    const result = await pool.query(
      'UPDATE boards SET title = $1, columns = $2 WHERE id = $3 RETURNING *',
      [title, columns, boardId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Ozini qiynama bunaqa board yoq' });
    }
    res.status(200).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Malumotlarni yangilashda xatolik bor' });
  }
};

export const deleteBoard = async (req, res) => {
  const { boardId } = req.params;
  try {
    await pool.query('DELETE FROM tasks WHERE "boardId" = $1', [boardId]);
    const result = await pool.query('DELETE FROM boards WHERE id = $1 RETURNING *', [boardId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Bizni lox deb oylayabsanmi aslida sen oqigan kitobni biz yozganmiz (Xato)' });
    }
    res.status(200).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Boardni ochirishda xatolik bor' });
  }
};
